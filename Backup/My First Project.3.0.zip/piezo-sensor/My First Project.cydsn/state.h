/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#if !defined(STATE_H)
#define STATE_H

    #define STATE_READY 1
    #define STATE_PLAY  2

    extern int state;

#endif /* !define STATE_H */

/* [] END OF FILE */
